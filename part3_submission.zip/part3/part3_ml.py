"""
Capstone Part 3 -- Advanced Modeling: Ensembles, Tuning, and Full ML Pipeline
Rebuilds the exact Part 2 preprocessing/split (same random_state=42) so
X_train_scaled, X_test_scaled, y_clf_train, y_clf_test are identical to Part 2.
"""
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, roc_auc_score

np.random.seed(42)
log = []

def section(title):
    line = f"\n{'='*70}\n{title}\n{'='*70}"
    print(line); log.append(line)

def out(x=""):
    print(x); log.append(str(x))

# ----------------------------------------------------------------------
# Rebuild Part 2's exact preprocessing / split
# ----------------------------------------------------------------------
section("SETUP: Rebuilding Part 2's Preprocessing and Split")
df = pd.read_csv("/home/claude/cleaned_data.csv")
df["City"] = df["City"].fillna("Unknown")

y_reg = df["MonthlySalary"].copy()
y_clf = (y_reg > y_reg.median()).astype(int)
X = df.drop(columns=["EmployeeID", "MonthlySalary"])
X = pd.get_dummies(X, columns=["Department", "City"], drop_first=True)

X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test = train_test_split(
    X, y_reg, y_clf, test_size=0.2, random_state=42
)

scaler = StandardScaler()
scaler.fit(X_train)
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

feature_names = X.columns.tolist()
out(f"X_train_scaled: {X_train_scaled.shape}, X_test_scaled: {X_test_scaled.shape}")
out("Reconstructed identically to Part 2 (same random_state=42, same feature set).")

# ----------------------------------------------------------------------
# TASK 1: Decision Tree baseline (unconstrained)
# ----------------------------------------------------------------------
section("TASK 1: Decision Tree Baseline (Unconstrained)")
dt_base = DecisionTreeClassifier(random_state=42)  # max_depth=None (default)
dt_base.fit(X_train_scaled, y_clf_train)

train_acc_base = accuracy_score(y_clf_train, dt_base.predict(X_train_scaled))
test_acc_base = accuracy_score(y_clf_test, dt_base.predict(X_test_scaled))
out(f"Unconstrained Decision Tree -- Train accuracy: {train_acc_base:.4f}, Test accuracy: {test_acc_base:.4f}")
out(f"Train-test gap: {train_acc_base - test_acc_base:.4f}")

# ----------------------------------------------------------------------
# TASK 2: Controlled Decision Tree
# ----------------------------------------------------------------------
section("TASK 2: Controlled Decision Tree (max_depth=5, min_samples_split=20)")
dt_controlled = DecisionTreeClassifier(max_depth=5, min_samples_split=20, random_state=42)
dt_controlled.fit(X_train_scaled, y_clf_train)

train_acc_ctrl = accuracy_score(y_clf_train, dt_controlled.predict(X_train_scaled))
test_acc_ctrl = accuracy_score(y_clf_test, dt_controlled.predict(X_test_scaled))
out(f"Controlled Decision Tree -- Train accuracy: {train_acc_ctrl:.4f}, Test accuracy: {test_acc_ctrl:.4f}")
out(f"Train-test gap: {train_acc_ctrl - test_acc_ctrl:.4f}")

# ----------------------------------------------------------------------
# TASK 3: Gini vs Entropy
# ----------------------------------------------------------------------
section("TASK 3: Gini vs Entropy (both max_depth=5)")
dt_gini = DecisionTreeClassifier(max_depth=5, criterion="gini", random_state=42)
dt_gini.fit(X_train_scaled, y_clf_train)
acc_gini = accuracy_score(y_clf_test, dt_gini.predict(X_test_scaled))

dt_entropy = DecisionTreeClassifier(max_depth=5, criterion="entropy", random_state=42)
dt_entropy.fit(X_train_scaled, y_clf_train)
acc_entropy = accuracy_score(y_clf_test, dt_entropy.predict(X_test_scaled))

out(f"Gini    (max_depth=5) -- Test accuracy: {acc_gini:.4f}")
out(f"Entropy (max_depth=5) -- Test accuracy: {acc_entropy:.4f}")

# ----------------------------------------------------------------------
# TASK 4: Random Forest
# ----------------------------------------------------------------------
section("TASK 4: Random Forest (n_estimators=100, max_depth=10)")
rf = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
rf.fit(X_train_scaled, y_clf_train)

rf_train_acc = accuracy_score(y_clf_train, rf.predict(X_train_scaled))
rf_test_acc = accuracy_score(y_clf_test, rf.predict(X_test_scaled))
rf_auc = roc_auc_score(y_clf_test, rf.predict_proba(X_test_scaled)[:, 1])
out(f"Random Forest -- Train accuracy: {rf_train_acc:.4f}, Test accuracy: {rf_test_acc:.4f}, ROC-AUC: {rf_auc:.4f}")

importances = pd.DataFrame({"feature": feature_names, "importance": rf.feature_importances_})
importances = importances.sort_values("importance", ascending=False)
out("\nTop 5 features by importance:")
out(importances.head(5).to_string(index=False))

# ----------------------------------------------------------------------
# TASK 4a: Gradient Boosting
# ----------------------------------------------------------------------
section("TASK 4a: Gradient Boosting")
gb = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
gb.fit(X_train_scaled, y_clf_train)

gb_train_acc = accuracy_score(y_clf_train, gb.predict(X_train_scaled))
gb_test_acc = accuracy_score(y_clf_test, gb.predict(X_test_scaled))
gb_auc = roc_auc_score(y_clf_test, gb.predict_proba(X_test_scaled)[:, 1])
out(f"Gradient Boosting -- Train accuracy: {gb_train_acc:.4f}, Test accuracy: {gb_test_acc:.4f}, ROC-AUC: {gb_auc:.4f}")

# ----------------------------------------------------------------------
# TASK 4b: Feature ablation study
# ----------------------------------------------------------------------
section("TASK 4b: Feature Ablation Study")
lowest5 = importances.tail(5)["feature"].tolist()
out(f"5 lowest-importance features: {lowest5}")

drop_idx = [feature_names.index(f) for f in lowest5]
keep_idx = [i for i in range(len(feature_names)) if i not in drop_idx]

X_train_reduced = X_train_scaled[:, keep_idx]
X_test_reduced = X_test_scaled[:, keep_idx]

rf_reduced = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
rf_reduced.fit(X_train_reduced, y_clf_train)
rf_reduced_auc = roc_auc_score(y_clf_test, rf_reduced.predict_proba(X_test_reduced)[:, 1])

out(f"Full model AUC (all {len(feature_names)} features): {rf_auc:.4f}")
out(f"Reduced model AUC ({len(keep_idx)} features, 5 lowest-importance dropped): {rf_reduced_auc:.4f}")
out(f"AUC change: {rf_reduced_auc - rf_auc:+.4f}")

# ----------------------------------------------------------------------
# TASK 5: Cross-validated comparison
# ----------------------------------------------------------------------
section("TASK 5: Cross-Validated Comparison (5-fold Stratified, scoring=roc_auc)")
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

cv_models = {
    "LogisticRegression": LogisticRegression(max_iter=1000, class_weight="balanced", C=1.0, random_state=42),
    "DecisionTree(max_depth=5)": DecisionTreeClassifier(max_depth=5, min_samples_split=20, random_state=42),
    "RandomForest": RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42),
    "GradientBoosting": GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42),
}

cv_results = {}
for name, model in cv_models.items():
    scores = cross_val_score(model, X_train_scaled, y_clf_train, cv=skf, scoring="roc_auc", n_jobs=-1)
    cv_results[name] = (scores.mean(), scores.std())
    out(f"{name}: mean AUC = {scores.mean():.4f}, std = {scores.std():.4f}")

# ----------------------------------------------------------------------
# TASK 6: Hyperparameter tuning with GridSearchCV
# ----------------------------------------------------------------------
section("TASK 6: GridSearchCV -- Random Forest Pipeline")
pipeline = make_pipeline(
    SimpleImputer(strategy="median"),
    StandardScaler(),
    RandomForestClassifier(random_state=42),
)

param_grid = {
    "randomforestclassifier__n_estimators": [50, 100, 200],
    "randomforestclassifier__max_depth": [5, 10, None],
    "randomforestclassifier__min_samples_leaf": [1, 5],
}

grid_search = GridSearchCV(
    pipeline, param_grid,
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
    scoring="roc_auc", n_jobs=-1,
)
# Note: X_train (UNSCALED) is used here -- the pipeline handles imputation + scaling internally
grid_search.fit(X_train, y_clf_train)

out(f"Best params: {grid_search.best_params_}")
out(f"Best CV score (mean AUC): {grid_search.best_score_:.4f}")

n_configs = 3 * 3 * 2
out(f"\nTotal grid configurations: {n_configs} (3 n_estimators x 3 max_depth x 2 min_samples_leaf)")
out(f"Total model fits performed: {n_configs} x 5 folds = {n_configs * 5}")

best_pipeline = grid_search.best_estimator_

# ----------------------------------------------------------------------
# TASK 7: Manual learning curve
# ----------------------------------------------------------------------
section("TASK 7: Manual Learning Curve (Best Pipeline from Task 6)")
fractions = [0.2, 0.4, 0.6, 0.8, 1.0]
learning_rows = []

for f in fractions:
    n_rows = int(f * len(X_train))
    X_sub = X_train.iloc[:n_rows]
    y_sub = y_clf_train.iloc[:n_rows]

    pipe_f = make_pipeline(
        SimpleImputer(strategy="median"),
        StandardScaler(),
        RandomForestClassifier(**{k.replace("randomforestclassifier__", ""): v
                                   for k, v in grid_search.best_params_.items()},
                                random_state=42),
    )
    pipe_f.fit(X_sub, y_sub)

    train_auc = roc_auc_score(y_sub, pipe_f.predict_proba(X_sub)[:, 1])
    test_auc = roc_auc_score(y_clf_test, pipe_f.predict_proba(X_test)[:, 1])
    learning_rows.append({"Training fraction": f, "Training AUC": round(train_auc, 4), "Test AUC": round(test_auc, 4)})

learning_table = pd.DataFrame(learning_rows)
out(learning_table.to_string(index=False))

# ----------------------------------------------------------------------
# TASK 8: Serialize the best model
# ----------------------------------------------------------------------
section("TASK 8: Serialize Best Model")
joblib.dump(best_pipeline, "/home/claude/best_model.pkl")
out("Saved best_pipeline to best_model.pkl")

# Reload and predict demo
loaded_model = joblib.load("/home/claude/best_model.pkl")
sample_rows = X_test.iloc[:2]
sample_preds = loaded_model.predict(sample_rows)
out(f"\nReload-and-predict demo on 2 hand-picked test rows:")
out(f"Predictions: {sample_preds.tolist()}")
out(f"Actual labels: {y_clf_test.iloc[:2].tolist()}")

# ----------------------------------------------------------------------
# TASK 9: Summary comparison table (data for README)
# ----------------------------------------------------------------------
section("TASK 9: Summary Comparison Table (Parts 2 + 3)")

# Logistic regression test AUC (from Part 2, recomputed here for completeness)
log_reg_final = LogisticRegression(max_iter=1000, class_weight="balanced", C=1.0, random_state=42)
log_reg_final.fit(X_train_scaled, y_clf_train)
logreg_test_auc = roc_auc_score(y_clf_test, log_reg_final.predict_proba(X_test_scaled)[:, 1])

dt_test_auc = roc_auc_score(y_clf_test, dt_controlled.predict_proba(X_test_scaled)[:, 1])

summary_rows = [
    {"Model": "LogisticRegression (Part 2)", "CV Mean AUC": cv_results["LogisticRegression"][0],
     "CV Std AUC": cv_results["LogisticRegression"][1], "Test AUC": logreg_test_auc},
    {"Model": "DecisionTree (max_depth=5)", "CV Mean AUC": cv_results["DecisionTree(max_depth=5)"][0],
     "CV Std AUC": cv_results["DecisionTree(max_depth=5)"][1], "Test AUC": dt_test_auc},
    {"Model": "RandomForest", "CV Mean AUC": cv_results["RandomForest"][0],
     "CV Std AUC": cv_results["RandomForest"][1], "Test AUC": rf_auc},
    {"Model": "GradientBoosting", "CV Mean AUC": cv_results["GradientBoosting"][0],
     "CV Std AUC": cv_results["GradientBoosting"][1], "Test AUC": gb_auc},
    {"Model": "RandomForest (GridSearchCV tuned)", "CV Mean AUC": grid_search.best_score_,
     "CV Std AUC": np.nan, "Test AUC": roc_auc_score(y_clf_test, best_pipeline.predict_proba(X_test)[:, 1])},
]
summary_df = pd.DataFrame(summary_rows)
out(summary_df.to_string(index=False))

with open("/home/claude/part3_analysis_log.txt", "w") as f:
    f.write("\n".join(log))

print("\n\nDONE. Full log saved to part3_analysis_log.txt")
